var timer={};
function Menu_Top_F(tag) {
    var T=$(tag);
        var TimerAttr=T.attr('data-time');
    clearTimeout(timer[TimerAttr]);
    timer[TimerAttr]=setTimeout(function () {
        T.addClass('active_menu');
        $('>ul',T).fadeIn(0);
        $('>.menu_level3',T).fadeIn(0);
    },500);

}
function Menu_Top_NH(tag) {
    var T=$(tag);
    var TimerAttr=T.attr('data-time');
    clearTimeout(timer[TimerAttr]);
    timer[TimerAttr]=setTimeout(function () {
        T.removeClass('active_menu');
        $('>ul',T).fadeOut(0);
        $('>.menu_level3',T).fadeOut(0);
    },500);

}

